export default {
  "iconlocation": "\ue618",

  "icondanao1": "\ue623",

  "iconuser": "\ue607",

  "iconmaozi": "\ue602",

  "iconboy-sel": "\ue601",

  "iconman-sel": "\ueb95",

  "iconxin-o": "\ue711",

  "iconxin": "\ue82b",

  "iconmeiyan": "\ue659",

  "iconchoosehandle": "\ue619",

  "iconfanhui": "\ue63b",

  "iconbianji": "\ue66d",

  "icontanhuanv": "\ue68b",

  "icontanhuanan": "\ue68d",

  "iconxihuan": "\ue634",

  "iconwenjian": "\ue68f",

  "iconservice": "\ue7bb",

  "icondianzan": "\ue686",

  "icontanhuayuyin": "\ue632",

  "icontanhuaxiaoxi": "\ue614",

  "iconshaixuan": "\ue631",

  "iconyuyinshuohuabao": "\ue667",

  "iconkaiguanclose": "\ue66b",

  "iconyuehoujifen": "\ue61b",

  "iconsuo": "\ue657",

  "iconxiala": "\ue617",

  "iconshuikanguowo": "\ue690",

  "iconsousuo": "\ue611",

  "iconguanbi": "\ue641",

  "icondianzan-o": "\ue65c",

  "icontupian": "\ue606",

  "iconfanzhuanjingtou": "\ue872",

  "icontanhuashipin": "\ue64e",

  "iconshipin": "\ue677",

  "iconbiaoqing": "\ue600",

  "iconselected": "\ue60d",

  "iconchenggong": "\ue669",

  "iconman": "\ue615",

  "iconnv": "\ue616",

  "iconnaozhong": "\ue61c",

  "iconyuyin": "\ue637",

  "iconhuxiangguanzhu": "\ue60f",

  "iconyibiaopan": "\ueb94",

  "icondingwei-o": "\ue620",

  "iconqianbao": "\ue621",

  "iconjia": "\ue794",

  "icontanhuaxiala": "\ue65b",

  "icontanhuatupian": "\ue6f5",

  "icongengduo": "\ue612",

  "iconpinglun": "\ue61e",

  "iconxiangji": "\ue7a5",

  "iconshengyin": "\ueae0",

  "iconshezhi": "\ue633",

  "iconshibai": "\ue60b",

  "iconrenshu": "\ue61d",

  "iconkefu": "\ue610",

  "icondingwei": "\ue638",

  "iconriqi": "\ue66a",

  "icondanao": "\ue61f",

  "iconxihuan-o": "\ue665",

  "icondongtai": "\ue613",

  "icontanhuakefu": "\ue62f",

  "icongonggao": "\ue6ff",

  "icontongxunlu": "\ue63a",

  "iconliaotian": "\ue75e",

  "iconxiaoxi": "\ue608",

  "icontanhuawode": "\ue609",

  "iconquanzi": "\ue60a",

  "iconyuyinshuohua": "\ue60c",

  "icontianjia": "\ue60e",

  "iconbuxihuan": "\ue61a"
}